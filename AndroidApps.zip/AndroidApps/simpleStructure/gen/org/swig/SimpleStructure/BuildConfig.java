/** Automatically generated file. DO NOT MODIFY */
package org.swig.SimpleStructure;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}